export type MobileAction = { action: 'open_app'; app: string } | { action: 'search_youtube' | 'search_web' | 'play_youtube'; query: string } | { action: 'whatsapp_message'; recipient: string; message: string; send?: boolean } | { action: 'read_screen' | 'open_accessibility_settings' | 'wake_screen' } | { action: 'tap_text'; text: string; confirmed?: boolean } | { action: 'tap_xy'; x: number; y: number } | { action: 'type_text'; text: string } | { action: 'scroll'; direction: 'up' | 'down' | 'left' | 'right' } | { action: 'press'; button: 'back' | 'home' | 'recents' | 'notifications' | 'quick_settings' | 'lock_screen' };
export const MOBILE_TOOL = {
  name: 'mobile_action',
  description: 'Perform an Android action requested by the user: open an installed app, search YouTube, search the web in Chrome/browser, or open a WhatsApp message draft for a saved contact or international number. With NIMRA phone control enabled it can also read the screen, tap, type, scroll and press Back/Home inside any non-blocked app (open the app first, then read_screen, act, and check the returned screen). Ask the user to confirm before any send, pay, post or delete, then pass confirmed=true. Never invent recipients, numbers or successful actions; report the real status the tool returns.',
  parameters: { type: 'OBJECT', properties: {
    action: { type: 'STRING', enum: ['open_app', 'search_youtube', 'search_web', 'whatsapp_message', 'read_screen', 'tap_text', 'tap_xy', 'type_text', 'scroll', 'press', 'open_accessibility_settings', 'wake_screen', 'play_youtube'] },
    app: { type: 'STRING', description: 'App name, such as WhatsApp (WP), YouTube or Chrome. Only for open_app.' },
    query: { type: 'STRING', description: 'The exact search requested by the user, or for play_youtube the song/video to play. Required for search actions and play_youtube.' },
    recipient: { type: 'STRING', description: 'Saved contact name as spoken, or a full international phone number with country code. Contacts are resolved locally.' },
    message: { type: 'STRING', description: 'Complete message the user requested. Ask for it if missing.' },
    send: { type: 'BOOLEAN', description: 'For whatsapp_message: true only when the user explicitly asked to send it now; NIMRA then taps Send and reports what the screen shows. Otherwise only a draft is prepared.' },
    text: { type: 'STRING', description: 'For tap_text: the visible label of the button or item to tap. For type_text: the exact text to type.' },
    x: { type: 'NUMBER', description: 'Screen x in pixels, only for tap_xy.' },
    y: { type: 'NUMBER', description: 'Screen y in pixels, only for tap_xy.' },
    direction: { type: 'STRING', enum: ['up', 'down', 'left', 'right'], description: 'For scroll: down shows content further below.' },
    button: { type: 'STRING', enum: ['back', 'home', 'recents', 'notifications', 'quick_settings', 'lock_screen'], description: 'For press.' },
    confirmed: { type: 'BOOLEAN', description: 'Set true ONLY after the user clearly said yes to a send, pay, post or delete tap.' },
  }, required: ['action'] },
};
/** Exact local typed commands; Live voice uses structured Gemini function calls. */
export function parseMobileAction(input: string): MobileAction | null {
  const text = input.trim().replace(/^(?:hey\s+)?(?:nimra|nimrah|myraa|myra|मायरा|निम्रा|निमरा|نمرہ|نمره)[,\s:]+/iu, '').replace(/^(?:please|can you|could you)\s+/i, '').trim();
  let match = /^(?:open\s+)?(?:youtube|you tube)(?:\s+and)?\s+search(?:\s+for)?\s+(.+)$/i.exec(text) || /^search(?:\s+for)?\s+(.+?)\s+on\s+youtube$/i.exec(text);
  if (match) return { action: 'search_youtube', query: match[1].trim() };
  match = /^(?:open\s+)?(?:chrome|google chrome|browser)(?:\s+and)?\s+search(?:\s+for)?\s+(.+)$/i.exec(text) || /^search(?:\s+for)?\s+(.+?)\s+(?:on|in)\s+(?:chrome|google|browser)$/i.exec(text);
  if (match) return { action: 'search_web', query: match[1].trim() };
  match = /^(?:message|msg|text)\s+(.+?)\s+(?:on|using)\s+(?:whatsapp|wp|wa)\s*:\s*(.+)$/is.exec(text) || /^(?:whatsapp|wp|wa)\s+(?:message|msg)(?:\s+to)?\s+(.+?)\s*:\s*(.+)$/is.exec(text);
  if (match) return { action: 'whatsapp_message', recipient: match[1].trim(), message: match[2].trim() };
  match = /^play\s+(.+?)\s+on\s+youtube$/i.exec(text.replace(/[.!?।]+$/u, ''));
  if (match) return { action: 'play_youtube', query: match[1].trim() };
  match = /^(?:go\s+)?(back|home)$/i.exec(text.replace(/[.!?।]+$/u, ''));
  if (match) return { action: 'press', button: match[1].toLowerCase() as 'back' | 'home' };
  if (/^(?:read|show)\s+(?:the\s+|my\s+)?screen[.!?]*$/i.test(text)) return { action: 'read_screen' };
  match = /^scroll\s+(up|down|left|right)$/i.exec(text.replace(/[.!?।]+$/u, ''));
  if (match) return { action: 'scroll', direction: match[1].toLowerCase() as 'up' | 'down' | 'left' | 'right' };
  match = /^type\s+(.+)$/is.exec(text);
  if (match && !/\band\b/i.test(match[1])) return { action: 'type_text', text: match[1].trim() };
  match = /^(?:tap|click)\s+(?:on\s+)?(.+?)[.!?]*$/i.exec(text);
  if (match && !/\band\b/i.test(match[1])) return { action: 'tap_text', text: match[1].trim(), confirmed: true };
  const openText = text.replace(/[.!?।]+$/u, '');
  match = /^(?:open|launch)\s+([\p{L}\p{N}][\p{L}\p{N} ._-]{0,79})$/iu.exec(openText) || /^(whatsapp|wp|wa|youtube|chrome)\s+(?:kholo|khol do|open karo)$/i.exec(openText);
  if (match && !/\band\b/i.test(match[1])) return { action: 'open_app', app: match[1].trim() };
  return null;
}
