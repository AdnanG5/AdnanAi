package com.myraa.mobile;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.PowerManager;
import android.os.Looper;
import android.provider.Settings;
import java.util.regex.Pattern;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.telephony.*;
import org.json.*;
import java.util.*;

/** Bounded Android actions: intents plus NIMRA phone control (accessibility) with blocked apps and confirmation for risky taps. */
public final class MobileActions {
  public static final int CONTACTS_REQUEST=88;
  public interface Result { void complete(String id,JSONObject result); }
  public interface Launcher { boolean installed(String pkg); Intent app(String label); boolean open(Intent intent); }
  public interface Contacts { boolean needsPermission(); List<Recipient> find(String name); }
  public static final class Recipient {
    public final String name,phone;
    public Recipient(String name,String phone){this.name=name;this.phone=phone;}
  }
  private final Activity activity;
  private final Result result;
  private final Launcher launcher;
  private final Contacts contacts;
  private Runnable pending;
  private String pendingId;
  private AlertDialog chooser;
  private String chooserId;
  private final Map<String,JSONObject> completed=new LinkedHashMap<>();
  public MobileActions(Activity activity,Result result) {
    this(activity,result,new Launcher(){
      public boolean installed(String pkg){try{activity.getPackageManager().getPackageInfo(pkg,0);return true;}catch(Exception e){return false;}}
      public Intent app(String label){
        PackageManager pm=activity.getPackageManager();Intent main=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for(ResolveInfo info:pm.queryIntentActivities(main,0))if(normalize(info.loadLabel(pm).toString()).equals(normalize(label))&&info.activityInfo.exported)
          return new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(info.activityInfo.packageName,info.activityInfo.name);
        return null;
      }
      public boolean open(Intent intent){try{activity.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));return true;}catch(ActivityNotFoundException|SecurityException e){return false;}}
    },new Contacts(){
      public boolean needsPermission(){return true;}
      public List<Recipient> find(String name){
        List<Recipient> found=new ArrayList<>();Set<String> seen=new HashSet<>();
        String escaped=name.replace("\\","\\\\").replace("%","\\%").replace("_","\\_");
        try(Cursor c=activity.getContentResolver().query(Phone.CONTENT_URI,new String[]{Phone.DISPLAY_NAME,Phone.NUMBER,Phone.NORMALIZED_NUMBER},Phone.DISPLAY_NAME+" LIKE ? ESCAPE '\\'",new String[]{"%"+escaped+"%"},Phone.DISPLAY_NAME+" ASC")){
          if(c!=null)while(c.moveToNext()&&found.size()<20){
            String raw=c.getString(2);if(raw==null||raw.isEmpty())raw=c.getString(1);
            String phone=international(raw,activity);if(phone!=null&&seen.add(phone))found.add(new Recipient(c.getString(0),phone));
          }
        }
        List<Recipient> exact=new ArrayList<>();for(Recipient r:found)if(normalize(r.name).equals(normalize(name)))exact.add(r);
        return exact.isEmpty()?found:exact;
      }
    });
  }
  public MobileActions(Activity activity,Result result,Launcher launcher,Contacts contacts){this.activity=activity;this.result=result;this.launcher=launcher;this.contacts=contacts;}
  public static String normalize(String input){return input==null?"":input.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+"," ");}
  private static String international(String raw,Activity activity){
    if(raw==null)return null;String clean=raw.replaceAll("[ ()-]","");if(clean.startsWith("00"))clean="+"+clean.substring(2);
    if(clean.matches("\\+[1-9][0-9]{7,14}"))return clean.substring(1);
    String country="";try{country=activity.getSystemService(TelephonyManager.class).getNetworkCountryIso();}catch(Exception ignored){}
    if(country==null||country.length()!=2){String language=activity.getSharedPreferences("myraa.mobile.v1",0).getString("language","hi-IN");country=language.endsWith("IN")?"IN":"US";}
    String e164=PhoneNumberUtils.formatNumberToE164(raw,country.toUpperCase(Locale.ROOT));return e164==null?null:e164.substring(1);
  }
  public static Intent search(String target,String query){
    if(query==null||query.trim().isEmpty()||query.length()>1000)throw new IllegalArgumentException("Say what you want to search for.");
    Uri uri="youtube".equals(target)?Uri.parse("https://www.youtube.com/results").buildUpon().appendQueryParameter("search_query",query.trim()).build():Uri.parse("https://www.google.com/search").buildUpon().appendQueryParameter("q",query.trim()).build();
    return new Intent(Intent.ACTION_VIEW,uri).addCategory(Intent.CATEGORY_BROWSABLE);
  }
  public static Intent draft(String phone,String message,String pkg){
    if(phone==null||!phone.matches("[1-9][0-9]{7,14}")||message==null||message.trim().isEmpty()||message.length()>4000)throw new IllegalArgumentException("A valid recipient and message are required.");
    return new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/"+phone).buildUpon().appendQueryParameter("text",message).build()).setPackage(pkg);
  }
  private JSONObject status(String status,String message){JSONObject value=new JSONObject();try{value.put("status",status).put("message",message);}catch(JSONException ignored){}return value;}
  private void finish(String id,String status,String message){JSONObject value=status(status,message);completed.put(id,value);while(completed.size()>64)completed.remove(completed.keySet().iterator().next());result.complete(id,value);}
  public void execute(String id,String name,String raw){
    if(id==null||!id.matches("[A-Za-z0-9-]{1,80}"))return;
    if(completed.containsKey(id)){result.complete(id,completed.get(id));return;}
    if(!"mobile_action".equals(name)){finish(id,"unsupported","That mobile action is unavailable.");return;}
    try{
      JSONObject args=new JSONObject(raw);String action=args.optString("action");
      if("open_app".equals(action)){openApp(id,args.optString("app"));return;}
      if("search_youtube".equals(action)||"search_web".equals(action)){
        boolean youtube=action.equals("search_youtube");Intent intent=search(youtube?"youtube":"web",args.optString("query"));String pkg=youtube?"com.google.android.youtube":"com.android.chrome";
        if(launcher.installed(pkg))intent.setPackage(pkg);else if(youtube&&launcher.installed("com.android.chrome"))intent.setPackage("com.android.chrome");
        boolean opened=launcher.open(intent);if(!opened&&intent.getPackage()!=null)opened=launcher.open(new Intent(intent).setPackage(null));
        finish(id,opened?"opened":"unavailable",opened?(youtube?"YouTube":"Browser")+" search opened.":"No app can open this search on this device.");return;
      }
      if("whatsapp_message".equals(action)){message(id,args.optString("recipient"),args.optString("message"),args.optBoolean("send",false));return;}
      if("play_youtube".equals(action)){playYoutube(id,args.optString("query"));return;}
      if(isAccessibilityAction(action)){accessibility(id,action,args);return;}
      finish(id,"unsupported","Supported actions: open an app, search YouTube or the web, prepare a WhatsApp message, and phone control (read screen, tap, type, scroll, press).");
    }catch(IllegalArgumentException e){finish(id,"invalid",e.getMessage());}catch(Exception e){finish(id,"failed","Android could not complete this action. Nothing was sent.");}
  }

  // ---- NIMRA phone control (accessibility) ----
  private static final Set<String> SCREEN_ACTIONS=new HashSet<>(Arrays.asList("read_screen","tap_text","tap_xy","type_text","scroll","press","open_accessibility_settings","wake_screen"));
  public static boolean isAccessibilityAction(String action){return action!=null&&SCREEN_ACTIONS.contains(action);}
  private static final Set<String> BLOCKED_PACKAGES=new HashSet<>(Arrays.asList(
    "com.google.android.permissioncontroller","com.android.permissioncontroller","com.android.packageinstaller","com.google.android.packageinstaller",
    "com.jazzcash.app","com.techlogix.mobilinkcustomer","pk.com.telenor.phoenix","com.google.android.apps.nbu.paisa.user","com.phonepe.app","net.one97.paytm",
    "com.google.android.apps.walletnfcrel","com.samsung.android.spay","com.paypal.android.p2pmobile"));
  private static final Pattern RISKY=Pattern.compile("(^|[^a-z])(send|pay|transfer|delete|remove|uninstall|buy|purchase|order|submit|post|bhej|bhejo)([^a-z]|$)");
  private static boolean blockedPackage(String pkg){
    if(pkg==null)return false;String p=pkg.toLowerCase(Locale.ROOT);
    return BLOCKED_PACKAGES.contains(p)||p.contains("bank")||p.contains("wallet")||p.contains("easypaisa")||p.contains("jazzcash")||p.contains("passwordmanager")||p.contains("authenticator");
  }
  private static boolean risky(String text){
    String t=normalize(text);return RISKY.matcher(t).find()||t.contains("بھیج")||t.contains("भेज")||t.contains("ادائیگی")||t.contains("भुगतान");
  }
  private static String clip(String text,int max){return text==null?"":text.length()<=max?text:text.substring(0,max-3)+"...";}
  private void accessibility(String id,String action,JSONObject args){
    if("open_accessibility_settings".equals(action)){
      boolean ok=launcher.open(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
      finish(id,ok?"opened":"unavailable",ok?"Accessibility settings opened. Turn on NIMRA phone control, then ask again.":"Android could not open Accessibility settings.");return;
    }
    final NimraAccessibilityService svc=NimraAccessibilityService.instance;
    if(svc==null){finish(id,"accessibility_required","NIMRA phone control is switched off. Ask the user to enable it in Settings > Accessibility > NIMRA phone control, or offer to open those settings. Nothing was done.");return;}
    final String pkg=svc.foregroundPackage();
    if(blockedPackage(pkg)){finish(id,"blocked","NIMRA does not read or control "+pkg+" (payments, banking, permissions or installer screens). Nothing was done.");return;}
    final String before=svc.snapshot(60);
    if("read_screen".equals(action)){finish(id,"screen","Foreground app: "+pkg+". Screen: "+(before.isEmpty()?"(no readable text)":clip(before,2400)));return;}
    boolean ok;String what;
    switch(action){
      case "tap_text":{
        String text=args.optString("text");if(text.trim().isEmpty()||text.length()>200){finish(id,"invalid","Tell me which button or text to tap.");return;}
        String target=svc.peekLabel(text);
        if(target==null){finish(id,"not_found","No visible button or text matches '"+text+"'. Screen: "+clip(before,1500));return;}
        if((risky(text)||risky(target))&&!args.optBoolean("confirmed",false)){finish(id,"confirmation_required","'"+target+"' could send, pay, post or delete something. Ask the user to confirm clearly, then repeat with confirmed=true. Nothing was done.");return;}
        String hit=svc.clickText(text);ok=hit!=null;what="Tapped '"+(hit==null?target:hit)+"'";break;}
      case "tap_xy":{
        double x=args.optDouble("x",-1),y=args.optDouble("y",-1);if(x<0||y<0||x>5000||y>10000){finish(id,"invalid","Give valid screen coordinates.");return;}
        ok=svc.tap((float)x,(float)y);what="Tapped at "+(int)x+","+(int)y;break;}
      case "type_text":{
        String text=args.optString("text");if(text.isEmpty()||text.length()>4000){finish(id,"invalid","Tell me the exact text to type.");return;}
        ok=svc.typeText(text);what="Typed the text into the input field";break;}
      case "scroll":{String d=args.optString("direction");ok=svc.scroll(d);what="Scrolled "+d;break;}
      case "press":{String b=args.optString("button");ok=svc.press(b);what="Pressed "+b;break;}
      default:finish(id,"unsupported","Unknown phone control action.");return;
    }
    if(!ok){finish(id,"failed",what.replace("Tapped","Could not tap").replace("Typed","Could not type").replace("Scrolled","Could not scroll").replace("Pressed","Could not press")+". Nothing changed. Screen: "+clip(before,1200));return;}
    final String done=what;
    new Handler(Looper.getMainLooper()).postDelayed(()->{
      NimraAccessibilityService now=NimraAccessibilityService.instance;
      String after=now==null?"":now.snapshot(60);String appNow=now==null?pkg:now.foregroundPackage();
      boolean changed=!after.equals(before)||!appNow.equals(pkg);
      finish(id,changed?"done":"no_visible_change",done+(changed?". The screen changed.":". The screen did not visibly change, so it may not have worked.")+" Now in "+appNow+": "+(after.isEmpty()?"(no readable text)":clip(after,1500)));
    },900);
  }
  private void playYoutube(String id,String query){
    final Intent intent;
    try{intent=search("youtube",query);}catch(IllegalArgumentException e){finish(id,"invalid",e.getMessage());return;}
    final String pkg="com.google.android.youtube";final boolean app=launcher.installed(pkg);
    if(app)intent.setPackage(pkg);else if(launcher.installed("com.android.chrome"))intent.setPackage("com.android.chrome");
    boolean opened=launcher.open(intent);if(!opened&&intent.getPackage()!=null)opened=launcher.open(new Intent(intent).setPackage(null));
    if(!opened){finish(id,"unavailable","No app can open YouTube on this device. Nothing was played.");return;}
    if(NimraAccessibilityService.instance==null||!app){finish(id,"search_opened","YouTube search for '"+clip(query,80)+"' is open, but NIMRA phone control is off or the YouTube app is missing, so I could not start a video. NOTHING IS PLAYING YET. Ask the user to tap a result.");return;}
    final Handler h=new Handler(Looper.getMainLooper());final int[] tries={0};
    h.postDelayed(new Runnable(){public void run(){
      final NimraAccessibilityService svc=NimraAccessibilityService.instance;
      if(svc!=null&&svc.foregroundPackage().equals(pkg)){
        String hit=svc.clickFirstContaining(new String[]{"play video"},new String[]{"sponsored","advertisement"});
        if(hit!=null){h.postDelayed(()->{
          NimraAccessibilityService now=NimraAccessibilityService.instance;String after=now==null?"":now.snapshot(25);
          finish(id,"play_tapped","Tapped the first YouTube result: '"+clip(hit,90)+"'. It should be playing now, but I cannot hear it. Screen: "+clip(after,300));
        },2500);return;}
      }
      if(++tries[0]>=16){finish(id,"search_opened","YouTube search for '"+clip(query,80)+"' is open, but I could not find a result to tap. NOTHING IS CONFIRMED AS PLAYING. Ask the user to tap one.");return;}
      h.postDelayed(this,600);
    }},2200);
  }
  private static final Pattern BANK_NAME=Pattern.compile("easypaisa|easy paisa|jazzcash|jazz cash|sadapay|nayapay|raast|paytm|phonepe|google pay|gpay|bank|wallet|ایزی پیسہ|جاز کیش|एज़ीपैसा|जैज़ कैश");
  private void openApp(String id,String input){
    String app=normalize(input);
    if(BANK_NAME.matcher(app).find()){finish(id,"blocked","NIMRA does not open banking or payment apps. Nothing was opened.");return;}if(app.isEmpty()||app.length()>100){finish(id,"invalid","Say which app to open.");return;}
    Intent intent=null;
    if(Arrays.asList("wp","wa","whats app","whatsapp","व्हाट्सएप").contains(app)){
      String pkg=whatsapp();if(pkg==null){finish(id,"not_installed","WhatsApp is not installed on this Android device.");return;}intent=activity.getPackageManager().getLaunchIntentForPackage(pkg);if(intent==null)intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/")).setPackage(pkg);
    }else if(Arrays.asList("youtube","you tube","यूट्यूब").contains(app))intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com")).setPackage(launcher.installed("com.google.android.youtube")?"com.google.android.youtube":launcher.installed("com.android.chrome")?"com.android.chrome":null);
    else if(Arrays.asList("chrome","google chrome","browser","क्रोम").contains(app))intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com")).setPackage(launcher.installed("com.android.chrome")?"com.android.chrome":null);
    else intent=launcher.app(input);
    if(intent==null){finish(id,"not_installed","No installed app matches that name.");return;}
    if(intent.getComponent()!=null&&blockedPackage(intent.getComponent().getPackageName())){finish(id,"blocked","NIMRA does not open banking or payment apps. Nothing was opened.");return;}
    boolean opened=launcher.open(intent);finish(id,opened?"opened":"unavailable",opened?"Opened "+input+".":"Android could not open "+input+".");
  }
  private String whatsapp(){return launcher.installed("com.whatsapp")?"com.whatsapp":launcher.installed("com.whatsapp.w4b")?"com.whatsapp.w4b":null;}
  private void message(String id,String recipient,String text,boolean send){
    if(whatsapp()==null){finish(id,"not_installed","WhatsApp is not installed on this Android device.");return;}
    if(recipient.trim().isEmpty()||recipient.length()>100||text.trim().isEmpty()||text.length()>4000){finish(id,"invalid","Tell me the recipient and the complete message.");return;}
    if(recipient.trim().matches("\\+?[0-9 ()-]+")){
      String phone=recipient.replaceAll("[ ()+-]","");if(phone.startsWith("00"))phone=phone.substring(2);boolean international=recipient.trim().startsWith("+")||recipient.trim().startsWith("00")||phone.length()>=11;if(!international||!phone.matches("[1-9][0-9]{7,14}")){finish(id,"invalid","Include the country code in the recipient phone number, for example +91.");return;}
      openDraft(id,new Recipient(recipient,phone),text,send);return;
    }
    if(contacts.needsPermission()&&activity.checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
      if(pending!=null){finish(id,"busy","Finish the current contact selection first.");return;}
      pendingId=id;pending=()->message(id,recipient,text,send);activity.requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},CONTACTS_REQUEST);return;
    }
    List<Recipient> matches=contacts.find(recipient.trim());
    if(matches.isEmpty()){finish(id,"not_found","No matching contact with a usable phone number was found. Give the full saved name or an international phone number.");return;}
    if(matches.size()==1){openDraft(id,matches.get(0),text,send);return;}
    if(chooser!=null){finish(id,"busy","Choose the recipient from the current list first.");return;}
    String[] labels=new String[matches.size()];for(int i=0;i<labels.length;i++)labels[i]=matches.get(i).name+" · +"+matches.get(i).phone;
    chooserId=id;chooser=new AlertDialog.Builder(activity).setTitle("Which "+recipient+"?").setItems(labels,(d,index)->{chooser=null;openDraft(id,matches.get(index),text,send);})
      .setNegativeButton("Cancel",(d,w)->{chooser=null;finish(id,"cancelled","Message cancelled. Nothing was sent.");}).setOnCancelListener(d->{chooser=null;finish(id,"cancelled","Message cancelled. Nothing was sent.");}).show();
  }
  private static final String[] SEND_LABELS={"Send","send","भेजें","भेजे","بھیجیں","ارسال کریں"};
  private void openDraft(String id,Recipient person,String text,boolean send){
    boolean opened=launcher.open(draft(person.phone,text,whatsapp()));
    if(!opened){finish(id,"unavailable","WhatsApp could not open this recipient. Nothing was sent.");return;}
    if(send)autoSend(id,person.name,text);
    else finish(id,"draft_opened","WhatsApp draft opened for "+person.name+". It is NOT sent yet: ask the user to confirm or tap Send themselves.");
  }
  /** User explicitly asked to send: wait for the WhatsApp draft, tap Send, then report only what the screen shows. */
  private void autoSend(String id,String name,String text){
    if(NimraAccessibilityService.instance==null){finish(id,"draft_opened","WhatsApp draft opened for "+name+", but NIMRA phone control is off, so I could not tap Send. NOTHING WAS SENT. Offer to open Accessibility settings or ask the user to tap Send.");return;}
    final Handler h=new Handler(Looper.getMainLooper());final int[] tries={0};
    h.postDelayed(new Runnable(){public void run(){
      final NimraAccessibilityService svc=NimraAccessibilityService.instance;
      if(svc!=null&&svc.foregroundPackage().startsWith("com.whatsapp")){
        String hit=svc.clickExact(SEND_LABELS);
        if(hit!=null){h.postDelayed(()->{
          NimraAccessibilityService now=NimraAccessibilityService.instance;String after=now==null?"":normalize(now.snapshot(80));
          String probe=normalize(text);if(probe.length()>20)probe=probe.substring(0,20);
          boolean shown=!probe.isEmpty()&&after.contains(probe);
          finish(id,"send_tapped","Tapped Send in WhatsApp for "+name+". "+(shown?"The message is visible in the chat. ":"I could not see the message in the chat, so check it. ")+"I cannot see delivery ticks.");
        },1200);return;}
      }
      if(++tries[0]>=14){finish(id,"draft_opened","WhatsApp draft is open for "+name+" but I could not find the Send button in time. NOTHING IS CONFIRMED AS SENT. Ask the user to tap Send.");return;}
      h.postDelayed(this,500);
    }},1500);
  }
  public void permissionResult(){Runnable retry=pending;String id=pendingId;pending=null;pendingId=null;if(retry==null)return;if(activity.checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED)retry.run();else finish(id,"permission_required","Contacts access was denied. Use a full international phone number or allow Contacts in Android app settings.");}
  public void cancel(String id){if(id==null||!id.matches("[A-Za-z0-9-]{1,80}"))return;if(completed.containsKey(id))return;if(id.equals(pendingId)){pending=null;pendingId=null;}if(id.equals(chooserId)&&chooser!=null){chooser.dismiss();chooser=null;chooserId=null;}finish(id,"cancelled","Action cancelled. Nothing was sent.");}
  public void close(){pending=null;pendingId=null;if(chooser!=null){chooser.dismiss();chooser=null;}}
}
