package com.myraa.mobile;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * NIMRA phone control. The user must switch this service on manually in
 * Android Settings > Accessibility. It can read the visible screen, tap, type,
 * scroll and press system buttons. All calls come from MobileActions, which
 * applies the safety rules (blocked apps, confirmation for risky taps).
 */
public final class NimraAccessibilityService extends AccessibilityService {
  public static volatile NimraAccessibilityService instance;
  public static volatile String lastPackage = "";

  public static boolean enabled() { return instance != null; }

  @Override protected void onServiceConnected() { instance = this; super.onServiceConnected(); }
  @Override public void onAccessibilityEvent(AccessibilityEvent event) {
    if (event != null && event.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && event.getPackageName() != null)
      lastPackage = event.getPackageName().toString();
  }
  @Override public void onInterrupt() { }
  @Override public boolean onUnbind(Intent intent) { instance = null; return super.onUnbind(intent); }
  @Override public void onDestroy() { instance = null; super.onDestroy(); }

  public String foregroundPackage() {
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root != null && root.getPackageName() != null) return root.getPackageName().toString();
    return lastPackage == null ? "" : lastPackage;
  }

  private static String label(AccessibilityNodeInfo node) {
    CharSequence text = node.getText();
    if (text == null || text.length() == 0) text = node.getContentDescription();
    return text == null ? "" : text.toString().replaceAll("\\s+", " ").trim();
  }

  private static void collect(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out, int depth) {
    if (node == null || depth > 45 || out.size() > 800) return;
    if (node.isVisibleToUser()) out.add(node);
    for (int i = 0; i < node.getChildCount(); i++) collect(node.getChild(i), out, depth + 1);
  }

  private List<AccessibilityNodeInfo> visibleNodes() {
    List<AccessibilityNodeInfo> nodes = new ArrayList<>();
    collect(getRootInActiveWindow(), nodes, 0);
    return nodes;
  }

  /** Compact text view of what is on screen. Password fields are never read. */
  public String snapshot(int maxItems) {
    StringBuilder out = new StringBuilder();
    int count = 0;
    for (AccessibilityNodeInfo node : visibleNodes()) {
      if (count >= maxItems || out.length() > 2600) break;
      String text = node.isPassword() ? "" : label(node);
      boolean input = node.isEditable();
      if (text.isEmpty() && !input) continue;
      if (text.length() > 80) text = text.substring(0, 77) + "...";
      if (count > 0) out.append(" | ");
      if (node.isPassword()) out.append("[password field]");
      else if (input) out.append("[input] ").append(text);
      else if (node.isClickable()) out.append("[tap] ").append(text);
      else out.append(text);
      count++;
    }
    return out.toString();
  }

  private static String norm(String s) { return s == null ? "" : s.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " "); }

  private AccessibilityNodeInfo find(String wanted) {
    String target = norm(wanted);
    if (target.isEmpty()) return null;
    AccessibilityNodeInfo partial = null;
    for (AccessibilityNodeInfo node : visibleNodes()) {
      String value = norm(node.isPassword() ? "" : label(node));
      if (value.isEmpty()) continue;
      if (value.equals(target)) return node;
      if (partial == null && value.contains(target)) partial = node;
    }
    return partial;
  }

  /** Text of the node a tap_text request would hit, or null if nothing matches. */
  public String peekLabel(String wanted) { AccessibilityNodeInfo node = find(wanted); return node == null ? null : label(node); }

  /** Returns the matched label, or null if nothing was found or the tap was not delivered. */
  public String clickText(String wanted) {
    AccessibilityNodeInfo node = find(wanted);
    return node == null ? null : clickNode(node);
  }

  /** Taps only a node whose label equals one of the given labels exactly. */
  public String clickExact(String[] labels) {
    for (AccessibilityNodeInfo node : visibleNodes()) {
      String value = norm(node.isPassword() ? "" : label(node));
      if (value.isEmpty()) continue;
      for (String wanted : labels) if (value.equals(norm(wanted))) { String hit = clickNode(node); if (hit != null) return hit; }
    }
    return null;
  }

  /** Taps the first visible node (top to bottom) whose label contains one of the tokens and none of the avoided words. */
  public String clickFirstContaining(String[] tokens, String[] avoid) {
    for (AccessibilityNodeInfo node : visibleNodes()) {
      String value = norm(node.isPassword() ? "" : label(node));
      if (value.isEmpty()) continue;
      boolean match = false;
      for (String token : tokens) if (value.contains(norm(token))) match = true;
      for (String bad : avoid) if (value.contains(norm(bad))) match = false;
      if (match) { String hit = clickNode(node); if (hit != null) return hit; }
    }
    return null;
  }

  private String clickNode(AccessibilityNodeInfo node) {
    String matched = label(node);
    AccessibilityNodeInfo walk = node;
    for (int i = 0; i < 7 && walk != null; i++) {
      if (walk.isClickable() && walk.isEnabled() && walk.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return matched;
      walk = walk.getParent();
    }
    Rect bounds = new Rect();
    node.getBoundsInScreen(bounds);
    return tap(bounds.centerX(), bounds.centerY()) ? matched : null;
  }

  public boolean tap(float x, float y) {
    if (Build.VERSION.SDK_INT < 24) return false;
    Path path = new Path();
    path.moveTo(x, y);
    GestureDescription gesture = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path, 0, 60)).build();
    return dispatchGesture(gesture, null, null);
  }

  /** direction is where the content should move into view: down shows content below. */
  public boolean scroll(String direction) {
    if (Build.VERSION.SDK_INT < 24) return false;
    DisplayMetrics m = getResources().getDisplayMetrics();
    float w = m.widthPixels, h = m.heightPixels, fx = w / 2, fy = h / 2, tx = fx, ty = fy;
    switch (norm(direction)) {
      case "down": fy = h * 0.72f; ty = h * 0.28f; break;
      case "up": fy = h * 0.28f; ty = h * 0.72f; break;
      case "right": fx = w * 0.78f; tx = w * 0.22f; break;
      case "left": fx = w * 0.22f; tx = w * 0.78f; break;
      default: return false;
    }
    Path path = new Path();
    path.moveTo(fx, fy);
    path.lineTo(tx, ty);
    GestureDescription gesture = new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(path, 0, 350)).build();
    return dispatchGesture(gesture, null, null);
  }

  /** Replaces the text of the focused input (or the first visible input). */
  public boolean typeText(String text) {
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root == null || text == null) return false;
    AccessibilityNodeInfo target = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
    if (target == null || !target.isEditable() || target.isPassword()) {
      target = null;
      for (AccessibilityNodeInfo node : visibleNodes()) if (node.isEditable() && !node.isPassword()) { target = node; break; }
    }
    if (target == null) return false;
    target.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
    Bundle args = new Bundle();
    args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
    return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
  }

  public boolean press(String button) {
    switch (norm(button)) {
      case "back": return performGlobalAction(GLOBAL_ACTION_BACK);
      case "home": return performGlobalAction(GLOBAL_ACTION_HOME);
      case "recents": return performGlobalAction(GLOBAL_ACTION_RECENTS);
      case "notifications": return performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
      case "quick_settings": return performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS);
      case "lock_screen": return Build.VERSION.SDK_INT >= 28 && performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
      default: return false;
    }
  }
}
