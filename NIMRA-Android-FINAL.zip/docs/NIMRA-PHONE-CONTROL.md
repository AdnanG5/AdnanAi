# NIMRA phone control (step 4)

Adds an Android Accessibility Service (`NimraAccessibilityService`) so NIMRA can
read the visible screen, tap by label or coordinates, type, scroll and press
Back / Home / Recents / Notifications / Quick settings / Lock screen.

Enable it: app Settings > "Enable NIMRA phone control", or Android Settings >
Accessibility > NIMRA phone control. Android does not let an app switch this on
by itself. For a sideloaded APK you may first need App info > ⋮ > "Allow
restricted settings".

Flow for another app: open_app -> read_screen -> tap_text / type_text / scroll
-> every call returns done / no_visible_change / failed / not_found plus the
new screen text, so the answer is based on what actually happened.

Safety rules in code (MobileActions.java):
- Banking, wallet, password manager, authenticator, permission-dialog and
  package-installer apps are blocked for reading and control.
- Taps on send / pay / transfer / delete / post / buy etc. return
  `confirmation_required` until the user clearly says yes (`confirmed=true`).
- Password fields are never read. Screen text is treated as untrusted data.

Privacy: unlike RC5, screen text from read_screen and action results IS sent to
Gemini so it can decide the next step. Nothing is sent unless you give a command.

Not tested on a device. Build with scripts/build-android.ps1, then test on a
real phone before relying on it.

## Step 5 additions
- WhatsApp auto-send: `whatsapp_message` with `send=true` opens the draft, taps
  the Send button (exact label match, WhatsApp only) and reports what the screen
  shows. It cannot see delivery ticks. Needs phone control enabled; otherwise the
  draft stays unsent and NIMRA says so.
- `wake_screen`: turns the screen on for 8 s (WAKE_LOCK). The phone stays locked.
- Banking/payment apps (Easypaisa, JazzCash, SadaPay, NayaPay, bank/wallet apps)
  are never opened, read or controlled.
- NOT included: always-on "Hey Nimra" listening with the screen off. That needs
  an on-device wake-word engine (e.g. Porcupine, which needs an access key).
  Without it, start Talk first; whether the Live call keeps listening with the
  screen off is untested.

## Step 6 additions
- `play_youtube`: opens YouTube search and, with phone control on, taps the first
  non-sponsored result labelled "play video". Reports play_tapped only after the
  tap; never claims it can hear the audio.
- Default text model is now `gemini-3.8-flash`; Live voice model stays
  `gemini-3.1-flash-live-preview`. Both can be changed in Settings. The API key
  is entered in the app Settings (stored encrypted on the phone), never in code.
- Live voice retries up to twice (2.5 s, 5 s) after a timeout or connection error.
