"""Creates build/icon.png (dark square with a teal N) if it does not exist."""
import os, struct, sys, zlib
out = sys.argv[1]
os.makedirs(os.path.dirname(out), exist_ok=True)
if os.path.exists(out):
    sys.exit(0)
try:
    from PIL import Image, ImageDraw, ImageFont
    img = Image.new("RGB", (256, 256), (15, 22, 27))
    draw = ImageDraw.Draw(img)
    font = None
    for path in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"):
        if os.path.exists(path):
            font = ImageFont.truetype(path, 174)
            break
    if font is None:
        raise RuntimeError("no font")
    box = draw.textbbox((0, 0), "N", font=font)
    draw.text(((256 - (box[2] - box[0])) / 2 - box[0], (256 - (box[3] - box[1])) / 2 - box[1]), "N", font=font, fill=(142, 225, 219))
    img.save(out)
except Exception:
    w = h = 256
    row = b"\x00" + bytes((15, 22, 27)) * w
    raw = row * h
    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")
    open(out, "wb").write(png)
