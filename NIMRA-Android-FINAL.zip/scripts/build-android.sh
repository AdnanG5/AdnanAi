#!/usr/bin/env bash
# Linux/CI port of scripts/build-android.ps1 (same steps, same tools).
# Needs: Node 22, JDK 21, Android SDK with platforms;android-35 and build-tools;35.0.0.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
: "${ANDROID_HOME:?ANDROID_HOME must point to the Android SDK}"
BT="$ANDROID_HOME/build-tools/35.0.0"
AJAR="$ANDROID_HOME/platforms/android-35/android.jar"
for f in "$AJAR" "$BT/aapt2" "$BT/d8" "$BT/zipalign" "$BT/apksigner"; do
  [ -e "$f" ] || { echo "Missing build prerequisite: $f"; exit 1; }
done
ASSETS="android/app/src/main/assets"

echo "== 1/9 Bundling the web UI (vite)"
npx vite build --config vite.mobile.config.ts
mkdir -p "$ASSETS/characters"

echo "== 2/9 Character model"
if [ -d assets/characters/evelyn ]; then
  cp -r assets/characters/evelyn "$ASSETS/characters/evelyn"
  echo "Character model copied."
else
  echo "WARNING: assets/characters/evelyn not found. The app will build but the 3D character will NOT show."
fi

echo "== 3/9 Personality"
node --import tsx scripts/export-mobile-personality.ts

BUILD="android/app/build/ci"
rm -rf "$BUILD"; mkdir -p "$BUILD/classes" "$BUILD/dex" "$BUILD/res/drawable" "$BUILD/res/xml" "$BUILD/res/values"

echo "== 4/9 Compiling Java"
find android/app/src/main/java -name '*.java' > "$BUILD/sources.txt"
javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -classpath "$AJAR" -d "$BUILD/classes" @"$BUILD/sources.txt"
jar --create --file "$BUILD/classes.jar" -C "$BUILD/classes" .

echo "== 5/9 DEX"
"$BT/d8" --lib "$AJAR" --min-api 26 --output "$BUILD/dex" "$BUILD/classes.jar"

echo "== 6/9 Resources"
python3 -m pip install --quiet pillow 2>/dev/null || true
python3 scripts/make-icon.py build/icon.png
cp build/icon.png "$BUILD/res/drawable/myraa_icon.png"
cp android/app/src/main/res/xml/nimra_accessibility.xml "$BUILD/res/xml/"
cp android/app/src/main/res/values/strings.xml "$BUILD/res/values/"
"$BT/aapt2" compile --dir "$BUILD/res" -o "$BUILD/resources.zip"
"$BT/aapt2" link --manifest android/app/src/main/AndroidManifest.xml -I "$AJAR" -A "$ASSETS" \
  --min-sdk-version 26 --target-sdk-version 35 -o "$BUILD/unsigned.apk" "$BUILD/resources.zip"

echo "== 7/9 Adding code to the APK"
( cd "$BUILD/dex" && zip -q -j ../unsigned.apk ./*.dex )

echo "== 8/9 Align and sign"
"$BT/zipalign" -f -p 4 "$BUILD/unsigned.apk" "$BUILD/aligned.apk"
KS="$BUILD/ci-debug.keystore"
keytool -genkeypair -keystore "$KS" -storepass android -alias androiddebugkey -keypass android \
  -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=NIMRA Private Build,O=NIMRA,C=PK' >/dev/null 2>&1
mkdir -p artifacts/android
APK="artifacts/android/NIMRA-Mobile.apk"
"$BT/apksigner" sign --ks "$KS" --ks-key-alias androiddebugkey --ks-pass pass:android --key-pass pass:android --out "$APK" "$BUILD/aligned.apk"

echo "== 9/9 Verify"
"$BT/apksigner" verify --verbose "$APK"
"$BT/aapt2" dump badging "$APK" | head -5
sha256sum "$APK"
echo "DONE: $APK"
